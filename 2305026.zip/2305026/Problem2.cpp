#include<iostream>
using namespace std;
typedef long long ll;


int main() {
    int n,b,m;
    cin>>n>>b;
    int seats[n];
    for(int i=0; i<n; i++)
        cin>>seats[i];
    cin>>m;

    int count = 0;
    int per_benches = n/b;
    for(int i=0; i<b; i++) {
        int last_index = (i+1)*per_benches;
        for(int j=0; j<per_benches; j++) {
            int cur_idx = i*per_benches+j;
            if(!seats[cur_idx]){
                if((cur_idx-1 < i*per_benches || !(seats[cur_idx-1])) && (cur_idx+1>=last_index || seats[cur_idx+1]!=2)) count++;
            }
        }
        if(count >=m) break;
    }
    if(count>=m) cout<<"true\n";
    else cout<<"false\n";
    return 0;
}