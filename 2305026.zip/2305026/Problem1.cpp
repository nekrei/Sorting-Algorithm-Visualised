#include<iostream>
using namespace std;
typedef long long ll;


bool test_value(ll pref[], ll x, ll n, ll k) {
    ll count = 0;
    int j = 0;
    for(int i=1; i<=n; i++) {
        if(pref[i] - pref[j] > x) {
            count++; j = i-1;
        }
    }
    count++;
    return (count<=k);
}

int main() {
    int n,k;
    cin>>n>>k;

    ll array[n], prefix_sum[n+1];
    prefix_sum[0] = 0;
    for(int i=0; i<n; i++) {
        cin>>array[i];
        prefix_sum[i+1] = array[i] + prefix_sum[i];
    }

    if(k>n) {
        cout<<-1<<"\n";
        return 0;
    }
    
    ll low = 0, high = prefix_sum[n];
    while(low<(high-1)) {
        ll mid = (low+high)/2;
        if(test_value(prefix_sum,mid,n,k)) high = mid;
        else low= mid+1;
    }

    if(!low && test_value(prefix_sum,low,n,k)) cout<<low<<"\n";
    else cout<<high<<"\n";
    return 0;
}